export const KEY_COOKIE_VIDEO_IDS: string = "videoIDs";
